# EcoArmor FieldRoutes MCP Server

Connects Claude to your FieldRoutes account so you can pull reports, build dashboards, search customers, view revenue, and more — all from inside Claude.ai.

---

## Tools Available to Claude

| Tool | What It Does |
|---|---|
| `search_customers` | Search all 800+ customers by name, city, zip, status |
| `get_customer` | Full details for a single customer |
| `search_subscriptions` | Recurring plans, next service dates, pricing |
| `search_appointments` | Scheduled & completed appointments by date/tech |
| `search_invoices` | Invoices by status, date range, amount |
| `search_payments` | Payments received, monthly collections |
| `search_tickets` | Service tickets / work orders with tech notes |
| `search_employees` | Technicians and staff |
| `search_routes` | Technician routes by date |
| `search_leads` | Sales leads in the pipeline |
| `get_office_info` | Account and office details |
| `get_revenue_summary` | Combined payment + invoice summary for any period |

---

## Deploy to Railway (Recommended — Free)

### Step 1: Create a GitHub Repo

1. Go to [github.com](https://github.com) → **New repository**
2. Name it `fieldroutes-mcp`, set to **Private**
3. Clone it locally, copy all files from this folder into it, and push

```bash
git init
git add .
git commit -m "Initial FieldRoutes MCP server"
git remote add origin https://github.com/YOUR_USERNAME/fieldroutes-mcp.git
git push -u origin main
```

### Step 2: Deploy on Railway

1. Go to [railway.app](https://railway.app) and sign in with GitHub
2. Click **New Project** → **Deploy from GitHub repo**
3. Select your `fieldroutes-mcp` repo
4. Railway will auto-detect it as a Node.js app

### Step 3: Set Environment Variables in Railway

In your Railway project → **Variables** tab, add these:

| Variable | Value |
|---|---|
| `FR_KEY` | `ea9595nrusisdapg5e6m0t0mp4rbs2min8h2723fsmpti931p5k44lp534qfg2d5` |
| `FR_TOKEN` | `40fravuinjpeuih38b9vhgc50itsvn0f8tg3vi7tb12ac52iohf4surcfqkbhmab` |
| `FR_DATABASE` | `ecoarmorpest` |
| `FR_OFFICE` | `1` |
| `PORT` | `3000` |

Railway sets `PORT` automatically — but add it explicitly to be safe.

### Step 4: Get Your Public URL

After deployment, Railway gives you a public HTTPS URL like:
```
https://fieldroutes-mcp-production-xxxx.up.railway.app
```

Test it by visiting that URL in your browser — you should see:
```json
{ "status": "ok", "service": "EcoArmor FieldRoutes MCP", "database": "ecoarmorpest" }
```

---

## Connect to Claude.ai

1. Go to [claude.ai](https://claude.ai) → **Settings** (bottom left)
2. Click **Customize** → **Connectors**
3. Click **Add connector**
4. Enter your Railway URL + `/mcp`:
   ```
   https://fieldroutes-mcp-production-xxxx.up.railway.app/mcp
   ```
5. Click **Add**

That's it. Claude will now have access to all 12 FieldRoutes tools.

---

## Using It in Claude

Enable the connector in a conversation using the **+** button → **Connectors**, then ask things like:

- *"How much revenue did we collect in March?"*
- *"Show me all active customers in Prosper, TX"*
- *"Which technician completed the most appointments this week?"*
- *"List all customers with outstanding balances over $100"*
- *"What subscriptions are up for renewal in the next 30 days?"*
- *"Build me a dashboard showing this month's numbers"*

---

## Troubleshooting

**404 errors:** The FieldRoutes base URL is auto-built as `https://ecoarmorpest.fieldroutes.com/api`. If that 404s, set `FR_BASE_URL` manually in Railway variables and try `https://api.fieldroutes.com/ecoarmorpest` instead.

**Empty results:** Some FieldRoutes free API tiers limit which endpoints are accessible. Check the FieldRoutes API docs at `https://fieldroutes.dev/documentation` while logged in.

**Auth errors:** Double-check that FR_KEY and FR_TOKEN match exactly what FieldRoutes shows in your API settings — no extra spaces.

---

## Local Development

```bash
cp .env.example .env
# .env already has your credentials filled in
node server.js
```

Then in Claude.ai, you can't use localhost directly (Claude requires a public HTTPS URL). For local testing, use [ngrok](https://ngrok.com):

```bash
npx ngrok http 3000
# Copy the https://xxxx.ngrok.io URL → add /mcp → paste into Claude connectors
```
