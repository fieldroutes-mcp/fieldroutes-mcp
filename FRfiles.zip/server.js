import express from "express";
import cors from "cors";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { z } from "zod";

// ── Config ────────────────────────────────────────────────────────────────────
const FR_KEY      = process.env.FR_KEY;
const FR_TOKEN    = process.env.FR_TOKEN;
const FR_DATABASE = process.env.FR_DATABASE || "ecoarmorpest";
const FR_OFFICE   = process.env.FR_OFFICE   || "1";
const FR_BASE     = process.env.FR_BASE_URL  || `https://${FR_DATABASE}.fieldroutes.com/api`;
const PORT        = process.env.PORT || 3000;

if (!FR_KEY || !FR_TOKEN) {
  console.error("ERROR: FR_KEY and FR_TOKEN environment variables are required.");
  process.exit(1);
}

// ── FieldRoutes API helper ────────────────────────────────────────────────────
async function frPost(endpoint, params = {}) {
  const url  = `${FR_BASE}/${endpoint}`;
  const body = {
    authenticationKey:   FR_KEY,
    authenticationToken: FR_TOKEN,
    officeIDs:           [parseInt(FR_OFFICE)],
    ...params,
  };

  const res = await fetch(url, {
    method:  "POST",
    headers: { "Content-Type": "application/json" },
    body:    JSON.stringify(body),
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`FieldRoutes ${res.status} — ${endpoint}: ${text}`);
  }

  return res.json();
}

// ── MCP Server factory (stateless — one per request) ─────────────────────────
function buildMcpServer() {
  const server = new McpServer({
    name:    "fieldroutes-ecoarmor",
    version: "1.0.0",
  });

  // ─── CUSTOMERS ─────────────────────────────────────────────────────────────
  server.tool(
    "search_customers",
    "Search EcoArmor customers. Returns name, address, phone, email, balance, status, subscription info. Leave all filters empty to get all customers.",
    {
      fname:       z.string().optional().describe("First name (partial match)"),
      lname:       z.string().optional().describe("Last name (partial match)"),
      email:       z.string().optional().describe("Email address"),
      phone:       z.string().optional().describe("Phone number"),
      city:        z.string().optional().describe("City"),
      zip:         z.string().optional().describe("ZIP code"),
      active:      z.enum(["0","1"]).optional().describe("1=Active only, 0=Inactive only"),
      customerIDs: z.array(z.number()).optional().describe("Array of specific customer IDs"),
    },
    async (args) => {
      const data = await frPost("customer/search", args);
      return { content: [{ type: "text", text: JSON.stringify(data, null, 2) }] };
    }
  );

  server.tool(
    "get_customer",
    "Get full details for a single customer by their FieldRoutes customer ID.",
    { customerID: z.number().describe("The FieldRoutes customer ID") },
    async ({ customerID }) => {
      const data = await frPost("customer/search", { customerIDs: [customerID] });
      return { content: [{ type: "text", text: JSON.stringify(data, null, 2) }] };
    }
  );

  // ─── SUBSCRIPTIONS ─────────────────────────────────────────────────────────
  server.tool(
    "search_subscriptions",
    "Search recurring service subscriptions — service plans, frequency, price, next service date. Use this to see your recurring revenue base.",
    {
      customerID:          z.number().optional().describe("Filter by customer ID"),
      subscriptionIDs:     z.array(z.number()).optional().describe("Specific subscription IDs"),
      active:              z.enum(["0","1"]).optional().describe("1=Active only, 0=Inactive"),
      nextServiceDateMin:  z.string().optional().describe("Next service date min (YYYY-MM-DD)"),
      nextServiceDateMax:  z.string().optional().describe("Next service date max (YYYY-MM-DD)"),
    },
    async (args) => {
      const data = await frPost("subscription/search", args);
      return { content: [{ type: "text", text: JSON.stringify(data, null, 2) }] };
    }
  );

  // ─── APPOINTMENTS ──────────────────────────────────────────────────────────
  server.tool(
    "search_appointments",
    "Search scheduled and completed service appointments. Great for daily route planning, technician workloads, and completion rates.",
    {
      customerID:      z.number().optional().describe("Filter by customer ID"),
      employeeID:      z.number().optional().describe("Filter by technician/employee ID"),
      status:          z.number().optional().describe("0=Pending, 1=Completed, 2=Cancelled"),
      dateMin:         z.string().optional().describe("Date min (YYYY-MM-DD)"),
      dateMax:         z.string().optional().describe("Date max (YYYY-MM-DD)"),
      appointmentIDs:  z.array(z.number()).optional().describe("Specific appointment IDs"),
    },
    async (args) => {
      const data = await frPost("appointment/search", args);
      return { content: [{ type: "text", text: JSON.stringify(data, null, 2) }] };
    }
  );

  // ─── INVOICES ──────────────────────────────────────────────────────────────
  server.tool(
    "search_invoices",
    "Search invoices. Use for revenue reports, outstanding balances, and billing history.",
    {
      customerID:  z.number().optional().describe("Filter by customer ID"),
      invoiceIDs:  z.array(z.number()).optional().describe("Specific invoice IDs"),
      status:      z.number().optional().describe("0=Unpaid, 1=Paid, 2=Partial"),
      dateMin:     z.string().optional().describe("Invoice date min (YYYY-MM-DD)"),
      dateMax:     z.string().optional().describe("Invoice date max (YYYY-MM-DD)"),
      amountMin:   z.number().optional().describe("Minimum invoice total"),
    },
    async (args) => {
      const data = await frPost("invoice/search", args);
      return { content: [{ type: "text", text: JSON.stringify(data, null, 2) }] };
    }
  );

  // ─── PAYMENTS ──────────────────────────────────────────────────────────────
  server.tool(
    "search_payments",
    "Search payments received. Use for revenue tracking, monthly totals, and collections.",
    {
      customerID:  z.number().optional().describe("Filter by customer ID"),
      paymentIDs:  z.array(z.number()).optional().describe("Specific payment IDs"),
      dateMin:     z.string().optional().describe("Payment date min (YYYY-MM-DD)"),
      dateMax:     z.string().optional().describe("Payment date max (YYYY-MM-DD)"),
    },
    async (args) => {
      const data = await frPost("payment/search", args);
      return { content: [{ type: "text", text: JSON.stringify(data, null, 2) }] };
    }
  );

  // ─── SERVICE TICKETS ───────────────────────────────────────────────────────
  server.tool(
    "search_tickets",
    "Search service tickets (work orders). Contains what was treated, products used, technician notes, and service details.",
    {
      customerID:  z.number().optional().describe("Filter by customer ID"),
      ticketIDs:   z.array(z.number()).optional().describe("Specific ticket IDs"),
      employeeID:  z.number().optional().describe("Filter by technician ID"),
      dateMin:     z.string().optional().describe("Service date min (YYYY-MM-DD)"),
      dateMax:     z.string().optional().describe("Service date max (YYYY-MM-DD)"),
    },
    async (args) => {
      const data = await frPost("ticket/search", args);
      return { content: [{ type: "text", text: JSON.stringify(data, null, 2) }] };
    }
  );

  // ─── EMPLOYEES ─────────────────────────────────────────────────────────────
  server.tool(
    "search_employees",
    "List or search technicians and office staff. Returns names, roles, and employee IDs.",
    {
      employeeIDs: z.array(z.number()).optional().describe("Specific employee IDs"),
      fname:       z.string().optional().describe("First name filter"),
      lname:       z.string().optional().describe("Last name filter"),
      active:      z.enum(["0","1"]).optional().describe("1=Active only"),
    },
    async (args) => {
      const data = await frPost("employee/search", args);
      return { content: [{ type: "text", text: JSON.stringify(data, null, 2) }] };
    }
  );

  // ─── ROUTES ────────────────────────────────────────────────────────────────
  server.tool(
    "search_routes",
    "Search technician routes by date. Returns stops, customers, and sequencing.",
    {
      employeeID:  z.number().optional().describe("Filter by technician/employee ID"),
      dateMin:     z.string().optional().describe("Route date min (YYYY-MM-DD)"),
      dateMax:     z.string().optional().describe("Route date max (YYYY-MM-DD)"),
      routeIDs:    z.array(z.number()).optional().describe("Specific route IDs"),
    },
    async (args) => {
      const data = await frPost("route/search", args);
      return { content: [{ type: "text", text: JSON.stringify(data, null, 2) }] };
    }
  );

  // ─── LEADS ─────────────────────────────────────────────────────────────────
  server.tool(
    "search_leads",
    "Search sales leads and prospects in the pipeline.",
    {
      leadIDs:   z.array(z.number()).optional().describe("Specific lead IDs"),
      fname:     z.string().optional().describe("First name filter"),
      lname:     z.string().optional().describe("Last name filter"),
      email:     z.string().optional().describe("Email filter"),
      dateMin:   z.string().optional().describe("Created date min (YYYY-MM-DD)"),
      dateMax:   z.string().optional().describe("Created date max (YYYY-MM-DD)"),
    },
    async (args) => {
      const data = await frPost("lead/search", args);
      return { content: [{ type: "text", text: JSON.stringify(data, null, 2) }] };
    }
  );

  // ─── OFFICE INFO ───────────────────────────────────────────────────────────
  server.tool(
    "get_office_info",
    "Get EcoArmor office/account details from FieldRoutes.",
    {},
    async () => {
      const data = await frPost("office/search");
      return { content: [{ type: "text", text: JSON.stringify(data, null, 2) }] };
    }
  );

  // ─── REVENUE SUMMARY (composite) ──────────────────────────────────────────
  server.tool(
    "get_revenue_summary",
    "Get a revenue summary for a date range. Pulls payments and invoices together and summarizes totals. Great for monthly/quarterly reporting.",
    {
      dateMin: z.string().describe("Start date (YYYY-MM-DD)"),
      dateMax: z.string().describe("End date (YYYY-MM-DD)"),
    },
    async ({ dateMin, dateMax }) => {
      const [payments, invoices] = await Promise.all([
        frPost("payment/search",  { dateMin, dateMax }),
        frPost("invoice/search",  { dateMin, dateMax }),
      ]);

      const payList = payments?.data  || payments?.payments  || [];
      const invList = invoices?.data  || invoices?.invoices  || [];

      const totalCollected = payList.reduce(
        (sum, p) => sum + parseFloat(p.amount || p.total || 0), 0
      );
      const totalInvoiced = invList.reduce(
        (sum, i) => sum + parseFloat(i.total  || i.amount  || 0), 0
      );

      const summary = {
        period:          { from: dateMin, to: dateMax },
        totalInvoiced:   `$${totalInvoiced.toFixed(2)}`,
        totalCollected:  `$${totalCollected.toFixed(2)}`,
        outstanding:     `$${(totalInvoiced - totalCollected).toFixed(2)}`,
        paymentCount:    payList.length,
        invoiceCount:    invList.length,
      };

      return {
        content: [{
          type: "text",
          text: JSON.stringify(summary, null, 2),
        }],
      };
    }
  );

  return server;
}

// ── Express App ───────────────────────────────────────────────────────────────
const app = express();
app.use(cors());
app.use(express.json());

// Health check
app.get("/", (req, res) => {
  res.json({
    status:   "ok",
    service:  "EcoArmor FieldRoutes MCP",
    version:  "1.0.0",
    database: FR_DATABASE,
    office:   FR_OFFICE,
    baseUrl:  FR_BASE,
  });
});

// Streamable HTTP MCP endpoint (new server instance per request = stateless)
app.post("/mcp", async (req, res) => {
  const mcpServer = buildMcpServer();
  const transport = new StreamableHTTPServerTransport({
    sessionIdGenerator: undefined, // stateless mode
  });

  res.on("close", () => {
    transport.close();
    mcpServer.close();
  });

  try {
    await mcpServer.connect(transport);
    await transport.handleRequest(req, res, req.body);
  } catch (err) {
    console.error("MCP request error:", err);
    if (!res.headersSent) {
      res.status(500).json({ error: "Internal server error", detail: err.message });
    }
  }
});

app.listen(PORT, () => {
  console.log(`✅ EcoArmor FieldRoutes MCP running on port ${PORT}`);
  console.log(`   Base URL : ${FR_BASE}`);
  console.log(`   Office ID: ${FR_OFFICE}`);
});
